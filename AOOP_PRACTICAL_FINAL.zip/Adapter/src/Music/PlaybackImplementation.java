package Music;

public interface PlaybackImplementation {
void play();
}
