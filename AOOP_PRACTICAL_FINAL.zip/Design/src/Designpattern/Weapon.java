package Designpattern;

public interface Weapon {
}
