package Game;

public class EasyEnemy extends Enemy{
	public void attack() {
		System.out.println("Easy enemy attacks ligtly");
	}

}
