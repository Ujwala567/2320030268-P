package Game;

public abstract class Enemy {
public abstract void attack();
}
