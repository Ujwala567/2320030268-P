package Bike;

public abstract class Scooter  implements Vehicle{
	 public void drive() {
	        System.out.println("Riding a scooter.");
	    }
}
