package Iterator;

public enum LogLevel {
	 INFO, DEBUG, ERROR
}
