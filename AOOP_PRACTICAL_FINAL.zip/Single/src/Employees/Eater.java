package Employees;

public interface Eater {
	void eat();
}
