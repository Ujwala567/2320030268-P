package Employees;

public interface MessageService {
	void sendMessage(String message, String recipient);
}
