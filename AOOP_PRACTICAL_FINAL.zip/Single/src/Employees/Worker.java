package Employees;

public interface Worker {
	 void work();
}
